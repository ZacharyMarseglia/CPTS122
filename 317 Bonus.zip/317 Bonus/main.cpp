#include <stdio.h>
#include <string.h>

typedef enum {
    A, 
    B,
    C,
    Invalid
} State;

int process_input(const char* input) {
    State current_state = A; 
    int x1 = 0, x2 = 0;

    for (int i = 0; input[i] != '\0'; i++) {
        char symbol = input[i];

        switch (current_state) {
        case A:
            if (symbol == '0') {
                x1 = 0;
                x2 = 1;
                current_state = B;
            }
            else {
                current_state = Invalid;
            }
            break;

        case B:
            if (symbol == '1') {
                x1 = 1;
                x2 = 0;
                current_state = C;
            }
            else {
                current_state = Invalid;
            }
            break;

        case C:
            if (input[i + 1] == '\0') {  
                return 1;  
            }
            break;

        default:
            return 0;  
        }
    }
    return 0; 
}

int main() {
    char input[100];
    printf("Enter input string: ");
    scanf("%s", input);

    if (process_input(input)) {
        printf("YES\n");
    }
    else {
        printf("NO\n");
    }

    return 0;
}
