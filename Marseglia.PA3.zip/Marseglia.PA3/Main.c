/*****************************************************************
* Programmer: Zachary Marseglia
* Class: CptS 121, Spring 2024; lab section 4
* Programming Assignment: PA3
* February 8, 2024
* Description:
*****************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include "Header.h"


int main()
{
	//file in put output
	FILE* inputFile, * outputFile;
	//varibles for calculations
	int class_standing = 0;
	double gpa = 0, age = 0, sum_gpa = 0, sum_class_standing = 0, sum_age = 0, number1 = 0, number2 = 0, number3 = 0, number4 = 0, number5=0;
	double mean_gpa = 0, mean_class_standing = 0, mean_age = 0;
	double deviationGPA = 0, deviation1 = 0, deviation2 = 0, deviation3 = 0, deviation4 =0, deviation5 =0, variance_gpa = 0, std_deviation_gpa = 0, min_gpa = 0, max_gpa = 0;
	int studentID = 0;

	//opening input file for reading
	inputFile = fopen("text.txt", "r");
	if (inputFile == NULL)
	{
		//handling opening errors
		printf("No text inputs or input incorectly \n");
		return 1;
	}
	//opening out put file for writing 
	outputFile = fopen("output.dat", "w");
	if (outputFile == NULL)
	{
		// Handling file opening error and closing input file
		printf("No text inputs or input incorectly \n");
		fclose(inputFile);
		return 1;
	}
	// first student reading 
	studentID = read_integer(inputFile);
	double gpa1 = read_double(inputFile);
	class_standing = read_integer(inputFile);
	age = read_double(inputFile);
	
	// data for calculations
	sum_gpa += gpa1;
	sum_class_standing += class_standing;
	sum_age += age;

	// second student reading 
	studentID = read_integer(inputFile);
	double gpa2 = read_double(inputFile);
	class_standing = read_integer(inputFile);
	age = read_double(inputFile);
	
	// data for calculations
	sum_gpa += gpa2;
	sum_class_standing += class_standing;
	sum_age += age;

	// third student reading 
	studentID = read_integer(inputFile);
	double gpa3 = read_double(inputFile);
	class_standing = read_integer(inputFile);
	age = read_double(inputFile);
	
	// data for calculations
	sum_gpa += gpa3;
	sum_class_standing += class_standing;
	sum_age += age;

	// forth student reading 
	studentID = read_integer(inputFile);
	double gpa4 = read_double(inputFile);
	class_standing = read_integer(inputFile);
	age = read_double(inputFile);

	// data for calculations
	sum_gpa += gpa4;
	sum_class_standing += class_standing;
	sum_age += age;

	// fifth student reading 
	studentID = read_integer(inputFile);
	double gpa5 = read_double(inputFile);
	class_standing = read_integer(inputFile);
	age = read_double(inputFile);
	
	// data for calculations
	sum_gpa += gpa5;
	sum_class_standing += class_standing;
	sum_age += age;
	//calculates means and printing for the out put file 
	mean_gpa = calculate_mean(sum_gpa, 5);
	mean_class_standing = calculate_mean(sum_class_standing, 5);
	mean_age = calculate_mean(sum_age, 5);
	
	fprintf(outputFile, "%.2lf\n", mean_gpa);
	fprintf(outputFile, "%.2lf\n", mean_class_standing);
	fprintf(outputFile, "%.2lf\n", mean_age);

	// Calculating standard deviation and printing to output file
	deviation1 = calculate_deviation(gpa1, mean_gpa);
	deviation2 = calculate_deviation(gpa2, mean_gpa);
	deviation3 = calculate_deviation(gpa3, mean_gpa);
	deviation4 = calculate_deviation(gpa4, mean_gpa);
	deviation5 = calculate_deviation(gpa5, mean_gpa);

	variance_gpa = calculate_variance(deviation1, deviation2, deviation3, deviation4, deviation5, 5);
	std_deviation_gpa = calculate_standard_deviation(variance_gpa);

	fprintf(outputFile, "%.2lf\n", std_deviation_gpa);

	mean_class_standing = calculate_mean(sum_class_standing, 5);

	// Finding and printing the minimum and maximum GPA
	min_gpa = find_min(gpa1, gpa2, gpa3, gpa4, gpa5);
	max_gpa = find_max(gpa1, gpa2, gpa3, gpa4, gpa5);


	

	fprintf(outputFile, "%.2lf\n", min_gpa);
	fprintf(outputFile, "%.2lf\n", max_gpa);

	// Closing input and output files
	fclose(inputFile);
	fclose(outputFile);

	return 0;
} 

