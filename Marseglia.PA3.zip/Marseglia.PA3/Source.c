/*****************************************************************
* Programmer: Zachary Marseglia
* Class: CptS 121, Spring 2024; lab section 4
* Programming Assignment: PA3
* February 8, 2024
* Description:
*****************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include "Header.h"

// Function to read a double from the input file
double read_double(FILE* infile)
{
	double number;
	fscanf(infile, "%lf", &number);
	return number;
}

// Function to read an integer from the input file
int read_integer(FILE* infile)
{
	int number;
	fscanf(infile, "%d", &number);
	return number;
}

// Function to calculate the sum of five numbers
double calculate_sum(double number1, double number2, double number3, double number4, double number5)
{
	return number1 + number2 + number3 + number4 + number5;
}
// Function to calculate the mean of a set of numbers
double calculate_mean(double sum, int number)
{
	if (number == 0)
	{
		return -1;
	}
	return sum / number;
}
// Function to calculate the deviation of a number from the mean
double calculate_deviation(double number, double mean)
{
	return number - mean;
}
// Function to calculate the variance of a set of numbers
double calculate_variance(double deviation1, double deviation2, double deviation3, double deviation4, double deviation5, int number)
{
	return (pow(deviation1, 2) + pow(deviation2, 2) + pow(deviation3, 2) + pow(deviation4, 2) + pow(deviation5, 2)) / number;
}
// Function to calculate the standard deviation from the variance
double calculate_standard_deviation(double variance)
{
	return sqrt(variance);
}
// Function to find the maximum value from a set of numbers
double find_max(double number1, double number2, double number3, double number4, double number5)
{
	double max = number1;
	if (number2 > max) max = number2;
	if (number3 > max) max = number3;
	if (number4 > max) max = number4;
	if (number5 > max) max = number5;
	return max;
}
// Function to find the minimum value from a set of numbers
double find_min(double number1, double number2, double number3, double number4, double number5)
{
	double min = number1;
	if (number2 < min) min = number2;
	if (number3 < min) min = number3;
	if (number4 < min) min = number4;
	if (number5 < min) min = number5;
	return min;
}
// Function to print a double value to the output file
void print_double(FILE* outfile, double number)
{
	fprintf(outfile, "%lf \n", number);
}
